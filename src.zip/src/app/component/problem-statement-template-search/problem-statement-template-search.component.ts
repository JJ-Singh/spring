import { Component, OnInit } from '@angular/core';
import { ProblemStatementService } from 'src/app/service/problem-statement.service';

@Component({
  selector: 'app-problem-statement-template-search',
  templateUrl: './problem-statement-template-search.component.html',
  styleUrls: ['./problem-statement-template-search.component.css']
})
export class ProblemStatementTemplateSearchComponent implements OnInit {

  private problemStatementTemplates = [];
  private filteredProblemStatementTemplates = [];
  
  constructor(private problemStatementService: ProblemStatementService) { }

  ngOnInit() {
    this.problemStatementService.getProblemStatementData().subscribe(data => this.problemStatementTemplates = data);
  }

  problemStatementSearchButtonClick(value: string){
    if (value.length != 0){
      this.filteredProblemStatementTemplates = this.problemStatementTemplates.filter(data => 
        data.title.toLowerCase().indexOf(value.toLowerCase()) !== -1);
    }
    else{
      this.filteredProblemStatementTemplates = [];
    }
  }

  problemStatementSearchKeyPress(event: any, data: string){
    if(event.keyCode == 13){
      this.problemStatementSearchButtonClick(data);
    }
  }
}
