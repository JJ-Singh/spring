import { Component } from '@angular/core';

import { User } from './Model/user'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  topics = ['Angular', 'React', 'Vue'];
  hasError:boolean = true;
  userModel = new User("JJ", "jj@jj.com", "123456767", "default", "morning", true);
  validateTopic(value:string){
    if (value == "default"){
      this.hasError= true;
    }
    else{
      this.hasError= false;
    }
  }
}
