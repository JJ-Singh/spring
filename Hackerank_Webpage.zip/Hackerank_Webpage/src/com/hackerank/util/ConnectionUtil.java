package com.hackerank.util;

import java.sql.Connection;
import java.sql.DriverManager;

import com.hackerank.exception.HackerankException;

public class ConnectionUtil {
	
	public static Connection getConnection() throws HackerankException{
		Connection connObj = null;
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			connObj = DriverManager.getConnection("jdbc:mysql://localhost/hackerank", "root", "root");
			if (connObj == null) {
				System.out.println("No connection");
			} else {
				System.out.println("We got the  connection" + connObj);
			}
		} catch (Exception e) {
			throw new HackerankException("Unable to create Connection "+ e);
		}
		return connObj;
	}
}
