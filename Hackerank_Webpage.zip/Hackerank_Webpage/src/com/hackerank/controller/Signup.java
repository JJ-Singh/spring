package com.hackerank.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hackerank.dao.LoginRegDAO;
import com.hackerank.exception.HackerankException;
import com.hackerank.model.User;
import com.hackerank.util.ConnectionUtil;

/**
 * Servlet implementation class Signup
 */
@WebServlet("/Signup")
public class Signup extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String[] names = request.getParameter("fname_lastname").split(" ");
		PrintWriter pw = response.getWriter();
		Connection connObj = null;
		try {
			connObj = ConnectionUtil.getConnection();
			connObj.setAutoCommit(false);
			String firstName = names[0].trim();
			String lastName = names[1].trim();
			String email = request.getParameter("email");
			String pass = request.getParameter("password");
		
			LoginRegDAO.register(connObj,new User(firstName,lastName,email,pass));
			connObj.commit();
			request.setAttribute("msg", "Sign Up Successfull!");
			request.getRequestDispatcher("signup.jsp").forward(request, response);
		} catch (HackerankException e) {
//			pw.println(e.getMessage());
			request.setAttribute("error", "User Already Exists!");
			request.getRequestDispatcher("signup.jsp").forward(request, response);
			//e.printStackTrace();
		} catch (Exception e){
			e.printStackTrace();
		} finally{
			try {
				if(connObj!=null)
					connObj.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}
