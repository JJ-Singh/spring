package com.hackerank.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hackerank.dao.LoginRegDAO;
import com.hackerank.exception.HackerankException;
import com.hackerank.util.ConnectionUtil;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		Connection connObj = null;
		
		try {
			connObj = ConnectionUtil.getConnection();
			connObj.setAutoCommit(false);
			boolean status = LoginRegDAO.login(connObj, request.getParameter("email").trim(), request.getParameter("password"));
			connObj.commit();
			if(status){
				request.getRequestDispatcher("welcome.jsp").forward(request, response);
			}
			else{
				request.setAttribute("error", "Username or Password is Incorrect!");
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}
		} catch (HackerankException e) {
			e.printStackTrace();
		} catch (SQLException e){
			e.printStackTrace();
		} finally{
			try {
				if(connObj!=null)
					connObj.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
