package com.hackerank.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.hackerank.exception.HackerankException;
import com.hackerank.model.User;

public class LoginRegDAO {
	public static void register(Connection connObj,User user) throws HackerankException{
		PreparedStatement pstmt1 = null,pstmt2 = null;
		ResultSet result = null;
		try {
			pstmt1 = connObj.prepareStatement("select * from login where email = '" + user.getEmail() + "'");
			pstmt2 = connObj.prepareStatement("insert into login(firstname,lastname,email,password) values(?,?,?,?)");
			result = pstmt1.executeQuery();
			if(result.next()){
				throw new HackerankException("User Already Exists!");
			}
			else{
				pstmt2.setString(1, user.getFirstName());
				pstmt2.setString(2, user.getLastName());
				pstmt2.setString(3, user.getEmail());
				pstmt2.setString(4, user.getPassword());
				pstmt2.executeUpdate();
			}
		} catch (SQLException e) {
			throw new HackerankException(e);
		} finally{
			try {
				if (pstmt1!=null)
					pstmt1.close();
				if (pstmt2!=null)
					pstmt2.close();
				if (result!=null)
					result.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static boolean login(Connection connObj,String email, String password) throws HackerankException{
		PreparedStatement pstmt = null;
		ResultSet result = null;
		boolean flag = false;
		try {
			pstmt = connObj.prepareStatement("select * from login where email = '" + email + "' and password = '" + password +"'");
			result = pstmt.executeQuery();
			if(result.next()){
				flag = true;
			}
		} catch (SQLException e) {
			throw new HackerankException(e);
		} finally{
			try {
				if (pstmt!=null)
					pstmt.close();
				if (result!=null)
					result.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return flag;
	}
}
