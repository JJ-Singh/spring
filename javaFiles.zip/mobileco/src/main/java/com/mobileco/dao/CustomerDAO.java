package com.mobileco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mobileco.exceptions.MobilecoException;
import com.mobileco.model.Address;
import com.mobileco.model.Customer;

public class CustomerDAO {

	public CustomerDAO() {
	}
	public int registerCustomer(Connection connObj,Customer customer) throws MobilecoException{
		//PreparedStatement pstmt1 = null;
		PreparedStatement pstmt = null;
		ResultSet result = null;
//		ResultSet result2 = null;
		int key = 0;
		try {
			//pstmt1 = connObj.prepareStatement("select * from customer where email = '" + customer.getEmail() + "'");
			pstmt = connObj.prepareStatement("insert into customer(name,email,phone,password,address_id) values(?,?,?,?,?)");
			//result = pstmt1.executeQuery();
//			if(result.next()){
//				throw new MobilecoException("User already exists!");
//				}
//			else{
//

				pstmt.setString(1, customer.getName());
				pstmt.setString(2, customer.getEmail());
				pstmt.setString(3, customer.getPhone());
				pstmt.setString(4, customer.getPassword());
				pstmt.setInt(5, customer.getAddress().getId());
				pstmt.executeUpdate();
				result = pstmt.getGeneratedKeys();
				if(result.next()){
					key = result.getInt("id");
				}
//			}
			
		} catch (SQLException e) {
			throw new MobilecoException("Exception in registerCustomer "+ e);
		} finally{
			try {
//				if (pstmt1!=null)
//					pstmt1.close();
				if (pstmt!=null)
					pstmt.close();
				if (result!=null)
					result.close();
//				if (result2!=null)
//					result2.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return key;
	}
	
	public void updateCustomer(Connection connObj, Customer customer) throws MobilecoException{
		PreparedStatement pstmt = null;
		try {
			pstmt = connObj.prepareStatement("update customer set name = ?, email = ?,phone = ?,password = ?,address_id = ? where id = ?");
			pstmt.setString(1, customer.getName());
			pstmt.setString(2,customer.getEmail());
			pstmt.setString(3,customer.getPhone());
			pstmt.setString(4,customer.getPassword());
			pstmt.setInt(5, customer.getAddress().getId());
			pstmt.setInt(6,customer.getId());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new MobilecoException("Exception in registerCustomer "+ e);
		} finally{
			try {
				if (pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Customer getCustomerById(Connection connObj,int id) throws MobilecoException{
		PreparedStatement pstmt = null;
		String name;
		String email;
		String phone;
		String password;
		Address address;
		ResultSet result = null;
		try {
			AddressDAO temp = new AddressDAO();
			pstmt = connObj.prepareStatement("select * from customer where id = "+id);
			result = pstmt.executeQuery();
			if(result.next()){
				name = result.getString("name");
				email = result.getString("email");
				phone = result.getString("phone");
				password = result.getString("password");
				address = temp.getAddressById(connObj, result.getInt("address_id"));
			} else{
				throw new MobilecoException("No customer found!");
			}
			
		} catch (SQLException e) {
			throw new MobilecoException("Exception in registerCustomer "+ e);
		} finally{
			try {
				if (pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return new Customer(id, name, email, phone, password, address);
	}
}
