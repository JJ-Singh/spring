package com.payroll.services;

import java.sql.Connection;

import com.payroll.dao.AddressDAO;
import com.payroll.exceptions.PayrollException;
import com.payroll.model.Address;

public class AddressService implements IAddress {

	
	
	AddressDAO addressDao=new AddressDAO();
	public AddressService() {
	}

	@Override
	public int registerAddress(Connection connObj, Address address) throws PayrollException {

     
		return  addressDao.registerAddress(connObj, address);
		
	}

}
