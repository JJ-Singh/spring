package com.payroll.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.context.annotation.SessionScope;
import org.springframework.web.servlet.ModelAndView;

import com.payroll.exceptions.PayrollException;
import com.payroll.model.LoginDetails;
import com.payroll.services.LoginService;

@Controller
public class TestController {

	public TestController() {
		// TODO Auto-generated constructor stub
	}
	
	@GetMapping("/home")
	public String home(){
		System.out.println("Home");
		return "login";
		
	}
	
	@PostMapping("/LoginController")
	public ModelAndView login( LoginDetails loginDetails,LoginService loginService){
		
		System.out.println(loginDetails);
		System.out.println(loginService);
		
		String view="success";
		ModelAndView mav=null;
		
		try {
		boolean ch=	loginService.loginCheck(loginDetails);
		
		if(ch){
			 mav=new ModelAndView(view);
			
		}else{
			view="login";
			 mav=new ModelAndView(view);
			 mav.addObject("error", "username password is wrong");
		}
		
		} catch (PayrollException e) {
			// TODO Auto-generated catch block
			view="login";
			 mav=new ModelAndView(view);
			mav.addObject("error", e.getMessage());
			 e.printStackTrace();
		}
		
		return mav;
		
		
		
	}
	
	

}
