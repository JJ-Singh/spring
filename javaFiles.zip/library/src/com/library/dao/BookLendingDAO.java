package com.library.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import com.library.exception.LibraryException;
import com.library.model.Books;
public class BookLendingDAO {
	public static int bookLend(Connection connObj, String isbn, int subId) throws LibraryException{
		PreparedStatement pstmt = null;
		int flag = 0;
		try {
			pstmt = connObj.prepareStatement("insert into book_issued(issue_date,due_date,return_date,subscriber_s_id,Books_ISBN) values(curdate(),adddate(curdate(), interval 7 day),null,?,?)");
			if(BooksDAO.getQuantity(connObj, isbn)>0){
				pstmt.setInt(1, subId);
				pstmt.setString(2, isbn);
				pstmt.executeUpdate();
				BooksDAO.decQuantity(connObj, isbn);
				flag = 1;
			}
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if (pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				throw new LibraryException(e);
			}
		}
		return flag;
	}
	
//	public static ArrayList<Books> booksLended(Connection connObj, int subId) throws LibraryException{
//		PreparedStatement pstmt = null;
//		ArrayList<Books> books = new ArrayList<>();
//		try {
//			pstmt = connObj.prepareStatement("insert into book_issued(issue_date,due_date,return_date,subscriber_s_id,Books_ISBN) values(curdate(),adddate(curdate(), interval 7 day),null,?,?)");
//			if(BooksDAO.getQuantity(connObj, isbn)>0){
//				pstmt.setInt(1, subId);
//				pstmt.setString(2, isbn);
//				pstmt.executeUpdate();
//				BooksDAO.decQuantity(connObj, isbn);
//				flag = 1;
//			}
//		} catch (SQLException e) {
//			throw new LibraryException(e);
//		} finally{
//			try {
//				if (pstmt!=null)
//					pstmt.close();
//			} catch (SQLException e) {
//				throw new LibraryException(e);
//			}
//		}
//	}
}
