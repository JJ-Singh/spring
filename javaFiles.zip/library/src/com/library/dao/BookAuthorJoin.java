package com.library.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.library.exception.LibraryException;
import com.library.model.Books;

public class BookAuthorJoin {

	public static void addBookAuthorJoin(Connection connObj,ArrayList<Integer> authorIds,String ISBN) throws LibraryException{
		PreparedStatement pstmt = null;
		try {
			pstmt = connObj.prepareStatement("insert into book_author(Books_ISBN,author_id) values(?,?)");
			for(int i=0;i<authorIds.size();++i){
				pstmt.setString(1, ISBN);
				pstmt.setInt(2, authorIds.get(i));
				pstmt.executeUpdate();
			}
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void deleteBookAuthorJoin(Connection connObj,String ISBN) throws LibraryException{
		PreparedStatement pstmt = null;
		try {
			pstmt =  connObj.prepareStatement("delete from book_author where Books_ISBN = ?");
			pstmt.setString(1, ISBN);
			System.out.println("Rows effected "+pstmt.executeUpdate());
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
//	public static void upadateBookAuthorJoin(Connection connObj,ArrayList<Integer> authorIds,String ISBN) throws LibraryException{
//		PreparedStatement pstmt = null,pstmt2 = null;;
//		try {
//			pstmt =  connObj.prepareStatement("select * from book_author where Books_ISBN = ? and author_id = ?");
//			pstmt2 = connObj.prepareStatement("insert into book_author(Books_ISBN,author_id) values(?,?)");
//			for(int i=0;i<authorIds.size();++i){
//				pstmt.setString(1, ISBN);
//				pstmt.setInt(2, authorIds.get(i));
//				if(!pstmt.executeQuery().next()){
//					pstmt2.setString(1, ISBN);
//					pstmt2.setInt(2, authorIds.get(i));
//					pstmt2.executeUpdate();
//				}
//			}
//		} catch (SQLException e) {
//			throw new LibraryException(e);
//		} finally{
//			try {
//				if(pstmt!=null)
//					pstmt.close();
//			} catch (SQLException e) {
//				e.printStackTrace();
//			}
//		}
//	}
	public static ArrayList<Books> allBooks(Connection connObj) throws LibraryException{
		PreparedStatement pstmt = null;
		ResultSet result = null;
		ArrayList<Books> bookList = new ArrayList<>();
		try {
			pstmt = connObj.prepareStatement("select b.name,group_concat(a.name),b.ISBN,b.pub_date,b.quantity from book_author ba join Books b join author a on ba.Books_ISBN = b.ISBN and ba.author_id = a.id group by b.ISBN");
			result = pstmt.executeQuery();
			while(result.next()){
				bookList.add(new Books(result.getString(1),result.getString(2),result.getString(3),result.getString(4),result.getInt(5)));
			}
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(result!=null)
					result.close();
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return bookList;
	}
	public static ArrayList<Books> searchBooks(Connection connObj,String value) throws LibraryException{
		PreparedStatement pstmt = null;
		ResultSet result = null;
		ArrayList<Books> bookList = new ArrayList<>();
		try {
			pstmt = connObj.prepareStatement("select b.name,group_concat(a.name) gca,b.ISBN,b.pub_date,b.quantity from book_author ba join Books b join author a on ba.Books_ISBN = b.ISBN and ba.author_id = a.id group by b.ISBN having gca like '%"+value+"%' or b.name like '%"+value+"%'");
			result = pstmt.executeQuery();
			while(result.next()){
				bookList.add(new Books(result.getString(1),result.getString(2),result.getString(3),result.getString(4),result.getInt(5)));
			}
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(result!=null)
					result.close();
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return bookList;
	}
	
	public static Books getBookInfo(Connection connObj, String isbn) throws LibraryException{
		PreparedStatement pstmt = null;
		ResultSet result = null;
		String title,date,authors;
		int quantity;
		try {
			pstmt = connObj.prepareStatement("select b.ISBN ,b.name,b.pub_date,group_concat(a.name),b.quantity from books b join book_author ba join author a on ba.author_id = a.id and ba.Books_ISBN = b.ISBN group by b.ISBN having B.ISBN='"+isbn+"'");
			result = pstmt.executeQuery();
			result.next();
			title = result.getString(2);
			date = result.getString(3);
			authors = result.getString(4);
			quantity = result.getInt(5);
			
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				throw new LibraryException(e);
			}
		}
		return new Books(title,authors,isbn,date,quantity);
	}
}
