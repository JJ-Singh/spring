package com.library.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.library.exception.LibraryException;
import com.library.model.Subscriber;

public class SubscribersDAO {
	public static void addSubscriber(Connection connObj, String name, String email, String phonenumber) throws LibraryException{
		PreparedStatement pstmt = null;
		try {
			pstmt = connObj.prepareStatement("insert into subscriber(name,email_id,phonenumber) values(?,?,?)");
			pstmt.setString(1, name);
			pstmt.setString(2, email);
			pstmt.setString(3, phonenumber);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new LibraryException(e);
		}
	}
	
	public static Subscriber searchSubscriber(Connection connObj, int subId) throws LibraryException{
		PreparedStatement pstmt = null;
		ResultSet result = null;
		String name;
		String phoneNumber;
		String email;
		try {
			pstmt = connObj.prepareStatement("select * from subscriber where s_id = "+ subId);
			result = pstmt.executeQuery();
			if(result.next()){
				name = result.getString("name");
				phoneNumber = result.getString("phonenumber");
				email = result.getString("email_id");
			}else{
				throw new LibraryException("Employee Not Found!");
			}
			return new Subscriber(subId, name, phoneNumber, email);
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void updateSubscriber(Connection connObj, Subscriber sub) throws LibraryException{
		PreparedStatement pstmt = null;
		try {
			pstmt = connObj.prepareStatement("update subscriber set name = '" + sub.getName()+"',email_id = '"+ sub.getEmail()
			+"',phonenumber = '"+sub.getPhoneNumber()+"' where s_id = "+sub.getId());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new LibraryException(e);
		}
	}
	
	public static ArrayList<Subscriber> listSubscriber(Connection connObj, String value) throws LibraryException{
		PreparedStatement pstmt = null;
		ResultSet result = null;
		ArrayList<Subscriber> subscriberList = new ArrayList<>();
		try {
			pstmt = connObj.prepareStatement("select * from subscriber where s_id like '%" + value + "%' or name like '%" + value + "%'");
			result = pstmt.executeQuery();
			while(result.next()){
				subscriberList.add(new Subscriber(result.getInt(1), result.getString(2), result.getString(3),result.getString(4)));
			}
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(result!=null)
					result.close();
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return subscriberList;
	}
	
	public static ArrayList<Subscriber> allSubscribers(Connection connObj) throws LibraryException{
		PreparedStatement pstmt = null;
		ResultSet result = null;
		ArrayList<Subscriber> subscriberList = new ArrayList<>();
		try {
			pstmt = connObj.prepareStatement("select * from subscriber");
			result = pstmt.executeQuery();
			while(result.next()){
				subscriberList.add(new Subscriber(result.getInt(1), result.getString(2), result.getString(3),result.getString(4)));
			}
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(result!=null)
					result.close();
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return subscriberList;
	}
	
	public static void deleteSubscriber(Connection connObj, int subId) throws LibraryException{
		PreparedStatement pstmt = null;
		try {
			pstmt = connObj.prepareStatement("delete from subscriber where s_id = "+subId);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
