package com.library.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.library.exception.LibraryException;

public class BooksDAO {

	public static void addBook(Connection connObj,String ISBN,String title,String pubDate,int quantity) throws LibraryException{
		PreparedStatement pstmt = null;
		try {
			pstmt = connObj.prepareStatement("insert into Books(ISBN,name,pub_date,quantity) values(?,?,?,?)");
			pstmt.setString(1, ISBN);
			pstmt.setString(2, title);
			pstmt.setDate(3, Date.valueOf(pubDate));
			pstmt.setInt(4, quantity);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				throw new LibraryException(e);
			}
		}	
	}
	
	public static void updateBook(Connection connObj,String ISBN,String title,String pubDate,int quantity) throws LibraryException{
		PreparedStatement pstmt = null;
		try {
			pstmt = connObj.prepareStatement("update Books set name = ?,pub_date = ?,quantity = ? where ISBN = ?");
			pstmt.setString(1, title);
			pstmt.setDate(2, Date.valueOf(pubDate));
			pstmt.setInt(3, quantity);
			pstmt.setString(4, ISBN);
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				throw new LibraryException(e);
			}
		}
	}
	
	public static int getQuantity(Connection connObj,String ISBN) throws LibraryException{
		PreparedStatement pstmt = null;
		ResultSet result = null;
		int quantity;
		try {
			pstmt = connObj.prepareStatement("select * from Books where ISBN = '" + ISBN +"'");
			result = pstmt.executeQuery();
			if(result.next()){
//				title = result.getString("name");
//				date = result.getString("pub_date");
				quantity = result.getInt("quantity");
			}else{
				throw new LibraryException("No Book Found!");
			}
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				throw new LibraryException(e);
			}
		}
		return quantity;
	}
	
	public static void decQuantity(Connection connObj,String ISBN) throws LibraryException{
		PreparedStatement pstmt = null;
		try {
			pstmt = connObj.prepareStatement("update Books set quantity = quantity - 1 where ISBN = '" + ISBN +"'");
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				throw new LibraryException(e);
			}
		}
	}
}
