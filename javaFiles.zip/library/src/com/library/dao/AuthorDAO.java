package com.library.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.library.exception.LibraryException;

public class AuthorDAO {

	public static void addAuthor(Connection connObj,String[] authors) throws LibraryException{
		PreparedStatement pstmt = null,pstmt2=null;
		ResultSet result = null;
		ArrayList<Integer> authorIds = new ArrayList<>();
//		int authorId =0;
		try {
			pstmt = connObj.prepareStatement("insert into author(name) values(?)");
			pstmt2 = connObj.prepareStatement("select * from author where name=?");
			for (int i=0;i<authors.length;++i){
				pstmt2.setString(1, authors[i].trim());
				if(!pstmt2.executeQuery().next()){
					pstmt.setString(1, authors[i].trim());
					pstmt.executeUpdate();
				}
			}
			
			result = pstmt.getGeneratedKeys();
			while(result.next()){
				authorIds.add(result.getInt(1));
			}
		} catch (SQLException e) {
			throw new LibraryException(e);
		}finally{
			try {
				if(result!=null)
					result.close();
				if(pstmt!=null)
					pstmt.close();
				if(pstmt2!=null)
					pstmt2.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static ArrayList<Integer> getAuthorIdList(Connection connObj,String[] authors) throws LibraryException{
		PreparedStatement pstmt = null;
		ResultSet result = null;
		ArrayList<Integer> idList = new ArrayList<>();
		try {
			pstmt = connObj.prepareStatement("select id from author where name=?");
			for(int i = 0;i<authors.length;++i){
				pstmt.setString(1, authors[i].trim());
				result = pstmt.executeQuery();
				if(result.next())
					idList.add(result.getInt(1));
			}
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(result!=null)
					result.close();
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return idList;
	}
	
	public static void deleteNonNeededAuthors(Connection connObj) throws LibraryException{
		PreparedStatement pstmt = null;
		try {
			pstmt = connObj.prepareStatement("delete from author where id not in (select author_id from book_author)");
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new LibraryException(e);
		} finally{
			try {
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
}
