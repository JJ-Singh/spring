package com.library.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.library.exception.LibraryException;
import com.library.util.ConnectionUtil;

public class LoginDAO {

	public static boolean loginCheck(String username,String password) throws LibraryException{
		Connection connObj = null;
		PreparedStatement pstmt = null;
		boolean flag = false;
		try{
			connObj = ConnectionUtil.getConnection();
			pstmt = connObj.prepareStatement("Select * from login where username = ? and password = ?");
			pstmt.setString(1, username);pstmt.setString(2, password);
			if(pstmt.executeQuery().next())
				flag = true;
		}catch(SQLException e){
			throw new LibraryException(e);
		}finally{
			try {
				if(connObj!=null)
					connObj.close();
				if(pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				throw new LibraryException(e);
			}
		}
		return flag;
	}

}
