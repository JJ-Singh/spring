package com.library.util;

import java.sql.Connection;
import java.sql.DriverManager;

import com.library.exception.LibraryException;

public class ConnectionUtil {
	
	public static Connection getConnection() throws LibraryException{
		Connection connObj = null;
		try {
			DriverManager.registerDriver(new com.mysql.jdbc.Driver());
			connObj = DriverManager.getConnection("jdbc:mysql://localhost/librarymanagement", "root", "root");
			if (connObj == null) {
				System.out.println("No connection");
			} else {
				System.out.println("We got the  connection" + connObj);
			}
		} catch (Exception e) {
			throw new LibraryException("Unable to create Connection "+ e);
		}
		return connObj;
	}
}
