package com.library.model;

public class Books {
	private String title,authors,ISBN,pubDate;
	private int quantity;
	
	public Books(String title, String authors, String iSBN, String pubDate, int quantity) {
		super();
		this.title = title;
		this.authors = authors;
		ISBN = iSBN;
		this.pubDate = pubDate;
		this.quantity = quantity;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthors() {
		return authors;
	}
	public void setAuthors(String authors) {
		this.authors = authors;
	}
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	public String getPubDate() {
		return pubDate;
	}
	public void setPubDate(String pubDate) {
		this.pubDate = pubDate;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Books [title=" + title + ", authors=" + authors + ", ISBN=" + ISBN + ", pubDate=" + pubDate
				+ ", quantity=" + quantity + "]";
	}
	
}
