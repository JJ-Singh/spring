package com.library.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library.dao.SubscribersDAO;
import com.library.model.Subscriber;
import com.library.util.ConnectionUtil;

/**
 * Servlet implementation class UpdateSubscribers
 */
@WebServlet("/UpdateSubscribers")
public class UpdateSubscribers extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int subId = Integer.parseInt(request.getParameter("subId"));
		String isDelete = request.getParameter("delete");
		Connection connObj = null;
		PrintWriter wr = response.getWriter();
		try {
			connObj = ConnectionUtil.getConnection();
			connObj.setAutoCommit(false);
			if(isDelete!=null){
				SubscribersDAO.deleteSubscriber(connObj, subId);
				wr.println("Subscriber has been deleted!");
			}
			else{
				Subscriber sub = SubscribersDAO.searchSubscriber(connObj, subId);
				request.setAttribute("subName", sub.getName());
				request.setAttribute("subId", sub.getId());
				request.setAttribute("subEmail", sub.getEmail());
				request.setAttribute("subPhone", sub.getPhoneNumber());
			}
			connObj.commit();
		} catch (Exception e) {
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				System.out.println("Rollback ERROR! " + e1);
			}
			wr.println("ERROR While Deleting Subscriberk!");
			e.printStackTrace();
		} finally{
			if(connObj!=null)
				try {
					connObj.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int subId = Integer.parseInt(request.getParameter("subId"));
		String subName = request.getParameter("subName");
		String subEmail = request.getParameter("subEmail");
		String subPhone = request.getParameter("subPhone");
		PrintWriter wr = response.getWriter();
//		wr.println(subId+subEmail+subName+subPhone);
		Connection connObj = null;
		try {
			connObj = ConnectionUtil.getConnection();
			connObj.setAutoCommit(false);
			SubscribersDAO.updateSubscriber(connObj, new Subscriber(subId, subName, subPhone, subEmail));
			connObj.commit();
			wr.println("Subscriber Updated!");
		} catch (Exception e) {
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				System.out.println("Rollback ERROR! " + e1);
			}
			wr.println("ERROR While Adding New Book!");
			e.printStackTrace();
		} finally{
			if(connObj!=null)
				try {
					connObj.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}

}
