package com.library.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library.dao.SubscribersDAO;
import com.library.exception.LibraryException;
import com.library.util.ConnectionUtil;

/**
 * Servlet implementation class AddSubscribers
 */
@WebServlet("/AddSubscribers")
public class AddSubscribers extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String phonenumber = request.getParameter("phonenumber");
		PrintWriter wr = response.getWriter();
		Connection connObj = null;
		try {
			connObj = ConnectionUtil.getConnection();
			SubscribersDAO.addSubscriber(connObj, name, email, phonenumber);
			wr.println("Subscriber Successfully Added!");
		} catch (LibraryException e) {
			wr.println("Error while adding new subscriber!");
			e.printStackTrace();
		}finally{
			try {
				if(connObj != null)
					connObj.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

}
