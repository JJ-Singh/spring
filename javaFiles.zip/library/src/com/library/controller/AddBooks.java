package com.library.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library.dao.AuthorDAO;
import com.library.dao.BookAuthorJoin;
import com.library.dao.BooksDAO;
import com.library.util.ConnectionUtil;

/**
 * Servlet implementation class AddBooks
 */
@WebServlet("/AddBooks")
public class AddBooks extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String[] authors = request.getParameter("author").split(",");
		String title = request.getParameter("title");
		String ISBN = request.getParameter("ISBN");
		String pubDate = request.getParameter("pubDate");
		Connection connObj = null;
		PrintWriter wr = response.getWriter();
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		try {
			connObj = ConnectionUtil.getConnection();
			connObj.setAutoCommit(false);
			AuthorDAO.addAuthor(connObj, authors);
			ArrayList<Integer> authorIds = AuthorDAO.getAuthorIdList(connObj, authors);
			BooksDAO.addBook(connObj, ISBN, title, pubDate, quantity);
			BookAuthorJoin.addBookAuthorJoin(connObj, authorIds, ISBN);
			connObj.commit();
			wr.println("Book Successfully Added!");
		} catch (Exception e){
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				System.out.println("Rollback ERROR! " + e1);
			}
			wr.println("ERROR While Adding New Book!");
			e.printStackTrace();
		} finally{
			if(connObj!=null)
				try {
					connObj.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}

}
