package com.library.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library.dao.AuthorDAO;
import com.library.dao.BookAuthorJoin;
import com.library.dao.BooksDAO;
import com.library.exception.LibraryException;
import com.library.model.Books;
import com.library.util.ConnectionUtil;

/**
 * Servlet implementation class UpdateBooks
 */
@WebServlet("/UpdateBooks")
public class UpdateBooks extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//PrintWriter wr = response.getWriter();
		String isbn = request.getParameter("isbn");
		request.setAttribute("isbn", isbn);
		Connection connObj = null;
		try {
			connObj = ConnectionUtil.getConnection();
			Books book = BookAuthorJoin.getBookInfo(connObj, isbn);
			request.setAttribute("title", book.getTitle());
			request.setAttribute("authors", book.getAuthors());
			request.setAttribute("date", book.getPubDate());
			request.setAttribute("quantity", book.getQuantity());
		} catch (LibraryException e) {
			e.printStackTrace();
		} finally{
			if(connObj!=null){
				try {
					connObj.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			request.getRequestDispatcher("modifyBook.jsp").forward(request, response);
		}
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter wr = response.getWriter();
		String ISBN = request.getParameter("isbn");
		String title = request.getParameter("title");
		String[] authors = request.getParameter("authors").split(",");
		String pubDate = request.getParameter("pubDate");
		int quantity = Integer.parseInt(request.getParameter("quantity"));
		Connection connObj = null;
		try {
			connObj = ConnectionUtil.getConnection();
//			wr.println(ISBN+title+pubDate+quantity);
//			for (int i =0 ;i<authors.length ;++i )
//				wr.println(authors[i]);
			connObj.setAutoCommit(false);
			ArrayList<Integer> authorIds =  new ArrayList<>();
			BookAuthorJoin.deleteBookAuthorJoin(connObj,ISBN);
			AuthorDAO.deleteNonNeededAuthors(connObj);
			AuthorDAO.addAuthor(connObj, authors);
			authorIds = AuthorDAO.getAuthorIdList(connObj, authors);
			BooksDAO.updateBook(connObj, ISBN, title, pubDate, quantity);
			BookAuthorJoin.addBookAuthorJoin(connObj, authorIds, ISBN);
			connObj.commit();
			wr.println("Success!");
		} catch (Exception e) {
			try {
				connObj.rollback();
			} catch (SQLException e1) {
				System.out.println("Rollback ERROR! " + e1);
			}
			wr.println("ERROR While Adding New Book!");
			e.printStackTrace();
		} finally{
			if(connObj!=null)
				try {
					connObj.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
	}
}
