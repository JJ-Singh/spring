package com.library.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.library.dao.BookAuthorJoin;
import com.library.model.Books;
import com.library.util.ConnectionUtil;

/**
 * Servlet implementation class SearchBooks
 */
@WebServlet("/SearchBooks")
public class SearchBooks extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String value = request.getParameter("value");
		ArrayList<Books> bookList;
		Connection connObj = null;
		try {
			connObj = ConnectionUtil.getConnection();
			bookList = BookAuthorJoin.searchBooks(connObj, value);
			request.setAttribute("bookList", bookList);
			request.getRequestDispatcher("showBooks.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		} finally{
			if(connObj!=null){
				try {
					connObj.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}

}
