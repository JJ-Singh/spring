package com.library.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MainHome
 */
@WebServlet("/MainHome")
public class MainHome extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String value = request.getParameter("value");
		String entity = request.getParameter("entity");
		RequestDispatcher rd = null;
		request.setAttribute("value", value);
		if (entity.equals("0"))
			rd = request.getRequestDispatcher("SearchBooks");
		else
			rd =  request.getRequestDispatcher("SearchSubscribers");
		rd.forward(request, response);
	}

}
