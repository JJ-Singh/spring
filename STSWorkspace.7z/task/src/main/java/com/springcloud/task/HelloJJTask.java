package com.springcloud.task;

import org.springframework.boot.CommandLineRunner;
import org.springframework.cloud.task.listener.annotation.AfterTask;
import org.springframework.cloud.task.listener.annotation.BeforeTask;
import org.springframework.cloud.task.listener.annotation.FailedTask;
import org.springframework.cloud.task.repository.TaskExecution;
import org.springframework.stereotype.Component;

@Component
public class HelloJJTask implements CommandLineRunner {

	@Override
	public void run(String... args) throws Exception {
		System.out.println("This is a simple task!");
		for(String a: args)
			System.out.println(a);
	}
	
	@BeforeTask
	public void methodA(TaskExecution taskExecution) {
		System.out.println("Before Task");
	}

	@AfterTask
	public void methodB(TaskExecution taskExecution) {
		System.out.println("After Task");
	}

	@FailedTask
	public void methodC(TaskExecution taskExecution, Throwable throwable) {
		System.out.println("Failed Task");
	}
}
