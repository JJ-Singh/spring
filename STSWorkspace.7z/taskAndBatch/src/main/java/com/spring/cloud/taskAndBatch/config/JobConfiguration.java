package com.spring.cloud.taskAndBatch.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.support.ListItemReader;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableBatchProcessing
public class JobConfiguration {

	private final int CHUNK_SIZE = 2;

	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	@Autowired
	private StepBuilderFactory stepBuilderFactory;

	@Bean
	public Job job() {
		return jobBuilderFactory.get("Job1").start(stepBuilderFactory.get("J1Step1").tasklet(new Tasklet() {

			@Override
			public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
				System.out.println("This is a Job running! Step1");
				return RepeatStatus.FINISHED;
			}
		}).build()).next(stepBuilderFactory.get("J1Step2").tasklet(new Tasklet() {

			@Override
			public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
				System.out.println("This is a Job running! Step2");
				return RepeatStatus.FINISHED;
			}
		}).build()).build();
	}

	private class CustomItemReader<T> implements ItemReader<T> {
		private List<T> list;
		public CustomItemReader(List<T> list) {
			this.list = new ArrayList<>(list);
		}
		@Override
		public T read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
			if(list.isEmpty())
				return null;
			return list.remove(0);
		}
	}
	@Bean
	public Job job2() {
		return jobBuilderFactory.get("Job2")
				.start(stepBuilderFactory.get("J2Step1").<Integer, Integer>chunk(CHUNK_SIZE)
						.reader(new CustomItemReader<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)))
						//.reader(new ListItemReader<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)))
						.processor(new ItemProcessor<Integer, Integer>() {

							@Override
							public Integer process(Integer item) throws Exception {
								System.out.println("In Processor");
								return item * item;
							}

						}).writer(new ItemWriter<Integer>() {

							@Override
							public void write(List<? extends Integer> items) throws Exception {
								for (int item : items) {
									System.out.println("item is " + item);
								}
							}
						}).build())
				.build();
	}

//	public ItemProcessor<Integer, Integer> itemProcessor() {
//		return new ItemProcessor<Integer, Integer>() {
//
//			@Override
//			public Integer process(Integer item) throws Exception {
//				return item*item;
//			}
//			
//		};
//		
//	}

}
