import { Component, OnInit } from '@angular/core';
import { ProblemStatementService } from 'src/app/service/problem-statement.service';

@Component({
  selector: 'app-problem-statement-template-search',
  templateUrl: './problem-statement-template-search.component.html',
  styleUrls: ['./problem-statement-template-search.component.css']
})
export class ProblemStatementTemplateSearchComponent implements OnInit {

  private problemStatementTemplates = [];
  private filteredProblemStatementTemplates = [];
  private _searchText: string;
  private isClicked: boolean = false;
  private filteredProblemStatementTemplatesClasses = {
    "collapse" : this.isClicked
  }
  constructor(private problemStatementService: ProblemStatementService) { }

  ngOnInit() {
    this.problemStatementService.getProblemStatementData().subscribe(data => this.problemStatementTemplates = data);
  }

  get searchText(): string {
    return this._searchText;
  }

  set searchText(value: string){
    this._searchText = value;
    this.filteredProblemStatementTemplates = this.filterProblemStatementTemplate(value);
  }
  filterProblemStatementTemplate(value: string){
    return this.problemStatementTemplates.filter(data => 
      data.title.toLowerCase().indexOf(value.toLowerCase()) !== -1);
  }
  onClick(){
    if(this.isClicked){
      this.isClicked = false;
    }
    else{
      this.isClicked = true;
    }
  }
}
