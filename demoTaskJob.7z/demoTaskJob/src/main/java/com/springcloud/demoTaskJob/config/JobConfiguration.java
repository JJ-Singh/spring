package com.springcloud.demoTaskJob.config;

import java.util.List;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import com.springcloud.demoTaskJob.model.UserTransaction;
import com.springcloud.demoTaskJob.repository.UserTransactionRepository;

@Configuration
@EnableBatchProcessing
public class JobConfiguration {
	private final int CHUNK_SIZE = 2;
	
	@Autowired
	private UserTransactionRepository repository;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Bean
	public Job job1() {
		return jobBuilderFactory.get("Job1").start(stepBuilderFactory.get("Step1ofJob1").tasklet(new Tasklet() {

			@Override
			public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
				System.out.println("This is Job1 Step1 running!");
				return RepeatStatus.FINISHED;
			}
		}).build()).next(stepBuilderFactory.get("Step2ofJob1").tasklet(new Tasklet() {

			@Override
			public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
				System.out.println("This is Job1 Step2 running!");
				return RepeatStatus.FINISHED;
			}
		}).build()).build();
	}

	public FlatFileItemReader<UserTransaction> csvFileReader() {
		FlatFileItemReader<UserTransaction> reader = new FlatFileItemReader<>();
		reader.setResource(new ClassPathResource("file.csv"));
		reader.setLinesToSkip(1);
		reader.setLineMapper(lineMapper());
		return reader;
	}

	public LineMapper<UserTransaction> lineMapper() {
		DefaultLineMapper<UserTransaction> defaultLineMapper = new DefaultLineMapper<>();
		DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
		lineTokenizer.setStrict(false);
		lineTokenizer.setNames(new String[] { "userName", "userId", "transactions" });
		BeanWrapperFieldSetMapper<UserTransaction> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
		fieldSetMapper.setTargetType(UserTransaction.class);
		defaultLineMapper.setLineTokenizer(lineTokenizer);
		defaultLineMapper.setFieldSetMapper(fieldSetMapper);
		return defaultLineMapper;
	}

	@Bean
	public Job job2() {
		return jobBuilderFactory.get("CSV_to_DB")
				.start(stepBuilderFactory.get("CSV_to_DB_Step1").<UserTransaction, UserTransaction>chunk(CHUNK_SIZE)
						.reader(csvFileReader())
						.processor(new ItemProcessor<UserTransaction, UserTransaction>() {
							@Override
							public UserTransaction process(UserTransaction item) throws Exception {
								System.out.println("Item is " + item);
								return item;
							}
						})
						.writer(new ItemWriter<UserTransaction>() {
							@Override
							public void write(List<? extends UserTransaction> users) throws Exception {
								for (UserTransaction u : users) {
									System.out.println("In writter " + u);
									//repository.save(u);
								}
								repository.saveAll(users);
							}
						}).build())
				.build();
	}
}
