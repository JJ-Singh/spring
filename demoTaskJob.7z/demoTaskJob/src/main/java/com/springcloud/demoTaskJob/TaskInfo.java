package com.springcloud.demoTaskJob;

import org.springframework.boot.CommandLineRunner;
import org.springframework.cloud.task.listener.annotation.AfterTask;
import org.springframework.cloud.task.listener.annotation.BeforeTask;
import org.springframework.cloud.task.listener.annotation.FailedTask;
import org.springframework.cloud.task.repository.TaskExecution;
import org.springframework.stereotype.Component;

@Component
public class TaskInfo implements CommandLineRunner {

	@Override
	public void run(String... args) throws Exception {
		System.out.println("This is DemoTaskJob task running!");
	}

	@BeforeTask
	public void beforeTask(TaskExecution taskExecution) {
		System.out.println("Before TASK");
	}

	@AfterTask
	public void afterTask(TaskExecution taskExecution) {
		taskExecution.setExitMessage("DemoTaskJob ran successfully.");
		System.out.println("After TASK");
	}

	@FailedTask
	public void failedTask(TaskExecution taskExecution, Throwable throwable) {
		System.out.println("Failed TASK");
	}

}
