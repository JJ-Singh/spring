package com.springcloud.demoTaskJob.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UserTransaction {
	@Id
	private Long userId;
	private String userName;
	private Long userTransactions;
	
	public UserTransaction() {
		// TODO Auto-generated constructor stub
	}

	public UserTransaction(Long userId, String userName, Long userTransactions) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userTransactions = userTransactions;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getUserTransactions() {
		return userTransactions;
	}

	public void setUserTransactions(Long userTransactions) {
		this.userTransactions = userTransactions;
	}

	@Override
	public String toString() {
		return "UserTransaction [userName=" + userName + ", userId=" + userId + ", userTransactions=" + userTransactions
				+ "]";
	}
	
}
