package com.springcloud.demoTaskJob.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springcloud.demoTaskJob.model.UserTransaction;

public interface UserTransactionRepository extends JpaRepository<UserTransaction , Long>{

}
