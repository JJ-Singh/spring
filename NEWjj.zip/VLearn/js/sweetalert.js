function b1(){
	swal("Here's a message!");
};

function b2(){
	swal("Here's a message!", "It's pretty, isn't it?")
};

function b3(){
	swal("Good job!", "You clicked the button!", "success");
};

function b4(){
	swal({
	  title: "Are you sure?",
	  text: "Once deleted, you will not be able to recover this imaginary file!",
	  icon: "warning",
	  buttons: true,
	  dangerMode: true,
	})
	.then((willDelete) => {
	  if (willDelete) {
	    swal("Poof! Your imaginary file has been deleted!", {
	      icon: "success",
	    });
	  } else {
	    
	  }
	});
};

function b5(){
	/*swal({
		title: "Are you sure?",
		text: "You will not be able to recover this imaginary file!",
		icon: "warning",
		button: true,
		confirmButtonColor: '#DD6B55',
		confirmButtonText: 'Yes, delete it!',
		cancelButtonText: "No, cancel plx!",
		closeOnConfirm: false,
		closeOnCancel: false
	}).then(function(isConfirm){
    if (isConfirm){
      swal("Deleted!", "Your imaginary file has been deleted!", "success");
    } else {
      swal("Cancelled", "Your imaginary file is safe :)", "error");
    }
	});*/
	swal({
	  title: "Are you sure?",
	  text: "Once deleted, you will not be able to recover this imaginary file!",
	  icon: "warning",
	  buttons: true,
	  dangerMode: true,
	})
	.then((willDelete) => {
	  if (willDelete) {
	    swal("Poof! Your imaginary file has been deleted!", {
	      icon: "success",
	    });
	  } else {
	    swal("Your imaginary file is safe!");
	  }
	});
	};

function b6(){
	swal({
		title: "Sweet!",
		text: "Here's a custom image.",
		imageUrl: 'https://i.imgur.com/4NZ6uLY.jpg'
	});
};