(function($) {
	"use strict";
	
	// ______________Headerfixed
	$(window).on("scroll", function(e){
		if ($(window).scrollTop() >= 10) {
			$('.topbar').addClass('head');
			$('.left-sidebar').addClass('fixed-header');
			$('.left-sidebar').addClass('visible-title');
			$('.hide-menu').addClass('change-color');
			$('.nav-item').removeClass('display');
		}
		else {
			$('.topbar').removeClass('head');
			$('.left-sidebar').removeClass('fixed-header');
			$('.left-sidebar').removeClass('visible-title');
			$('.hide-menu').removeClass('change-color');
			$('.nav-item').addClass('display');

		}
    });
	
})(jQuery);