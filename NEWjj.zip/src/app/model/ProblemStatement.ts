export class ProblemStatement{
    private id: number;
    private title: string;
    private content: string;
    private input: any;
    private output: any;
    private duration: number;
    private sequence: number;

    constructor(id: number, title:string, content:string, duration:number, sequence:number, input:any = "", output:any = ""){
        this.id = id;
        this.title = title;
        this.content = content;
        this.duration = duration;
        this.sequence = sequence;
        this.input = input;
        this.output = output;
    }
}