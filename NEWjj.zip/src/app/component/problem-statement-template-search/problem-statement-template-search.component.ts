import { Component, OnInit } from '@angular/core';
import { ProblemStatementService } from 'src/app/service/problem-statement.service';

@Component({
  selector: 'app-problem-statement-template-search',
  templateUrl: './problem-statement-template-search.component.html',
  styleUrls: ['./problem-statement-template-search.component.css']
})
export class ProblemStatementTemplateSearchComponent implements OnInit {

  private problemStatementTemplates = [];
  private filteredProblemStatementTemplates = [];
  private searchResultShow: boolean = false;
  private displayAlert: boolean = false;
  private displayPreview: boolean = false;
  private selectedProblemStatement;

  constructor(private problemStatementService: ProblemStatementService) { }

  ngOnInit() {
    this.problemStatementService.getProblemStatementData().subscribe(data => this.problemStatementTemplates = data);
  }

  problemStatementSearchButtonClick(value: string){
    this.displayPreview = false;    
    if (value.length != 0){
      this.displayAlert = false;
      this.searchResultShow = true;
      this.filteredProblemStatementTemplates = this.problemStatementTemplates.filter(data => 
        data.title.toLowerCase().indexOf(value.toLowerCase()) !== -1);
    }
    else{
      this.displayAlert = true;
      this.searchResultShow = false;
      this.filteredProblemStatementTemplates = [];
    }
  }

  problemStatementPreview(data){
    this.selectedProblemStatement = data;
    this.searchResultShow = false;
    this.displayPreview = true;
  }

  problemStatementAddToSkill(){

  }

  problemStatementResults(){
    this.displayPreview = false;
    this.searchResultShow = true;
  }
}
