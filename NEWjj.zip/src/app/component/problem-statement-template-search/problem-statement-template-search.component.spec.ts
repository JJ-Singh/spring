import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProblemStatementTemplateSearchComponent } from './problem-statement-template-search.component';

describe('ProblemStatementTemplateSearchComponent', () => {
  let component: ProblemStatementTemplateSearchComponent;
  let fixture: ComponentFixture<ProblemStatementTemplateSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProblemStatementTemplateSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProblemStatementTemplateSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
