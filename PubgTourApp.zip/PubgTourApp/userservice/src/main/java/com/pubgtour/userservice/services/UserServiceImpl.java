package com.pubgtour.userservice.services;

import com.pubgtour.userservice.exceptions.UserAlreadyExistsException;
import com.pubgtour.userservice.exceptions.UserNotFoundException;
import com.pubgtour.userservice.model.User;

public class UserServiceImpl implements UserService {

	@Override
	public boolean saveUser(User user) throws UserAlreadyExistsException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public User findByUserNameAndPassword(String userName, String password) throws UserNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

}
