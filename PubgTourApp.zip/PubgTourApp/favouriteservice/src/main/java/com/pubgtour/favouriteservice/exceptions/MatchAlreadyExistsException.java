package com.pubgtour.favouriteservice.exceptions;

@SuppressWarnings("serial")
public class MatchAlreadyExistsException extends Exception {

	public MatchAlreadyExistsException(String message) {
		super(message);
	}

}
