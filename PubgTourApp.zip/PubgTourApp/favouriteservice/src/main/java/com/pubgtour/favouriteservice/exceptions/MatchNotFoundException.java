package com.pubgtour.favouriteservice.exceptions;

@SuppressWarnings("serial")
public class MatchNotFoundException extends Exception {

	public MatchNotFoundException(String message) {
		super(message);
	}

}
