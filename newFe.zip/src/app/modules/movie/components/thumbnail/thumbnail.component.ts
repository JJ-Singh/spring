import { Component, OnInit, Input } from '@angular/core';
import { Movie } from '../../movie';
import { MovieService } from '../../movie.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'movie-thumbnail',
  templateUrl: './thumbnail.component.html',
  styleUrls: ['./thumbnail.component.css']
})
export class ThumbnailComponent implements OnInit {
  @Input()
  movie: Movie;
  @Input()
  useWatchlistApi: boolean;
  constructor(private movieService: MovieService, private snackbar: MatSnackBar) { }

  ngOnInit() { }

  addToWatchlist() {
    this.movieService.addMovieToWatchlist(this.movie).subscribe(() => {
      this.snackbar.open(this.movie.title + " Added To Your Wishlist", "", {
        duration: 4000
      });
    });
  }
  deleteFromWatchlist() {
    this.movieService.deleteMovieFromwatchlist(this.movie).subscribe(() => {
      this.snackbar.open(this.movie.title + " Is Deleted From Your Wishlist", "", {
        duration: 4000
      });
    });
  }
  updateFromWatchlist() {
    this.movieService;
  }
}
