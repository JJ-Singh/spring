import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, from } from 'rxjs';
import { retry, map } from 'rxjs/operators';
import { Movie } from './movie';

@Injectable({
  providedIn: 'root'
})
export class MovieService {
  tmdbEndpoint: string = "https://api.themoviedb.org/3/movie/";
  imagePrefix: string = "https://image.tmdb.org/t/p/w500";
  apiKey: string = "e5dc618a85d798a96af2b5f9c3fe963a";
  watchlistEndpoint: string = "http://localhost:3000/watchlist";
  constructor(private http: HttpClient) { 
  }

  getMovies(type: string, page: number = 1): Observable<Array<Movie>>{
    return this.http.get(this.tmdbEndpoint + type + "?api_key=" + this.apiKey + "&language=en-US&page=" + page).pipe(retry(3),
    map(this.pickMovieResults),
    map(this.transformPosterPath.bind(this)));
  }
  transformPosterPath(movies): Array<Movie>{
    return movies.map(movie => {
      movie.poster_path = `${this.imagePrefix}${movie.poster_path}`;
      return movie;
    });
  }
  pickMovieResults(response) {
    return response['results'];
  }
  addMovieToWatchlist(movie) {
    return this.http.post(this.watchlistEndpoint, movie);
  }
  getWatchlistedMovies(): Observable<Array<Movie>> {
    return this.http.get<Array<Movie>>(this.watchlistEndpoint);
  }
  deleteMovieFromwatchlist(movie) {
    return this.http.delete(this.watchlistEndpoint+"/"+movie.id);
  }
}
