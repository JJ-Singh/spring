import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TmdbContainerComponent } from './components/tmdb-container/tmdb-container.component';
import { WatchlistComponent } from './components/watchlist/watchlist.component';

const routes: Routes = [
    {
        path: "movies",
        children: [
            {path: "", redirectTo: "popular", pathMatch: "full"},
            {
                path: "popular",
                component: TmdbContainerComponent,
                data: {
                    movieType: "popular"
                }
            },
            {
                path: "top_rated",
                component: TmdbContainerComponent,
                data: {
                    movieType: "top_rated"
                }
            },
            {
                path: "watchlist",
                component: WatchlistComponent
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class MovieRoutingModule{}