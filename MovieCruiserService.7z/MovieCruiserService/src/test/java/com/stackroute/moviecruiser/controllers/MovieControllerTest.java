package com.stackroute.moviecruiser.controllers;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mockito;
//import org.mockito.MockitoAnnotations;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.http.MediaType;
//import org.springframework.test.context.junit4.SpringRunner;
//import org.springframework.test.web.servlet.MockMvc;
//import org.springframework.test.web.servlet.setup.MockMvcBuilders;
//
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.verifyNoMoreInteractions;
//import static org.mockito.Mockito.when;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
//import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
//import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
//import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
//
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.stackroute.moviecruiser.controller.MovieController;
//import com.stackroute.moviecruiser.domain.Movie;
//import com.stackroute.moviecruiser.service.MovieService;
//
//
//@RunWith(SpringRunner.class)
//@WebMvcTest(MovieController.class)
//public class MovieControllerTest {
//
//	@Autowired
//	private transient MockMvc mvc;
//	
//	@MockBean
//	private transient MovieService service;
//	
//	private transient Movie movie;
//	
//	static List<Movie> movies;
//	
//	@InjectMocks
//	private MovieController movieController;
//	
//	@Before
//	public void setup(){
//		
//		MockitoAnnotations.initMocks(this);
//		movie=new Movie(3706,"1234","BatmanBegins","VeryGood action movie","22/11/2015",null,4.9,33,"arun");
//		mvc=MockMvcBuilders.standaloneSetup(movieController).build();
//		movies=new ArrayList<>();
//		movie=new Movie(3789,"1234", "Superman", "good Movie", "www.abc.com", "2015-03-23",4.5,112,"arun");
//		movies.add(movie);
//		movie=new Movie(3386,"1234", "Superman1", "good Movie1", "www.abc.com1", "2015-03-23",4.5,112,"arun");
//		movies.add(movie);
//	}
//	
//	@Test
//	public void testSaveNewMovie() throws Exception{
//		String token="eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhcnVuIiwiaWF0IjoxNTUzMzQzMjUwfQ.Fl0RnWL2nE9lWcbgzPkuxFIsdeaB-Eyrjjp6CLTU7q0";
//		when(service.saveMovie(movie)).thenReturn(true);
//		mvc.perform(post("/api/v1/movie").header("autorization", "Bearer "+token).contentType(MediaType.APPLICATION_JSON).content(jsonToString(movie)))
//		.andExpect(status().isCreated()).andDo(print());
//		verify(service,times(1)).saveMovie(Mockito.any(Movie.class));
////		verifyNoMoreInteractions(service);
//	}
//	
//	@Test
//	public void testDeleteMovieById() throws Exception{
//		// TODO Auto-generated method stub
//		when(service.deleteMovieById(1)).thenReturn(true);
//		mvc.perform(delete("/api/v1/movie/{id}",1)).andExpect(status().isOk());
//		verify(service, times(1)).deleteMovieById(1);
//		verifyNoMoreInteractions(service);
//	}
//	
//	@Test
//	public void testFetchMovieById() throws Exception{
//		when(service.getMovieById(1)).thenReturn(movies.get(0));
//		mvc.perform(get("/api/v1/movie/{id}",1)).andExpect(status().isOk());
//		verify(service,times(1)).getMovieById(1);
//		verifyNoMoreInteractions(service);
//	}
//	
//	@Test
//	public void testGetMyMovies() throws Exception{
//		String token="eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhcnVuIiwiaWF0IjoxNTUzMzQzMjUwfQ.Fl0RnWL2nE9lWcbgzPkuxFIsdeaB-Eyrjjp6CLTU7q0";
//		when(service.getMyMovies("arun")).thenReturn(movies);
//		mvc.perform(get("/api/v1/movie").header("autorization", "Bearer "+token)
//				.contentType(MediaType.APPLICATION_JSON)).andExpect(status().isOk()).andDo(print());
//		verify(service, times(1)).getMyMovies("arun");
//		verifyNoMoreInteractions(service);
//	}
//	
//	private static String jsonToString(Movie movie) {
//		String result = null;
//		try {
//			final ObjectMapper mapper = new ObjectMapper();
//			result = mapper.writeValueAsString(movie);
//		} catch (Exception e) {
//			result = "Json parse error";
//		}
//		return result;
//	}
//}
//
//

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.moviecruiser.controller.MovieController;
import com.stackroute.moviecruiser.domain.Movie;
import com.stackroute.moviecruiser.service.MovieService;

import static org.mockito.Mockito.*;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;



@RunWith(SpringRunner.class)
@WebMvcTest(MovieController.class)
public class MovieControllerTest {
	
	@Autowired
	private transient MockMvc movieMockMvc;
	
	@MockBean
	private transient MovieService service;
	
	@InjectMocks
	private MovieController movieController;
	
	private transient Movie movie;
	
	static List<Movie> movies;
	
	@Before
	public void setUp(){
		
		MockitoAnnotations.initMocks(this);
		movies = new ArrayList<>();
		movieMockMvc = MockMvcBuilders.standaloneSetup(movieController).build();
		movie = new Movie(1,"123","Bahubali","blockbuster movie","www.abc.com","2014-07-08",49.5,100,"arun");
		movies.add(movie);
		movie = new Movie(2,"124","Bahubali-2","blockbuster movie","www.abc.com","2014-07-08",49.5,100,"arun");
		movies.add(movie);
	}
	
	@Test
	public void testSaveNewMovieSucess() throws Exception{
		
		String token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhcnVuIiwiaWF0IjoxNTUzMzQzMjUwfQ.Fl0RnWL2nE9lWcbgzPkuxFIsdeaB-Eyrjjp6CLTU7q0";
		when(service.saveMovie(movie)).thenReturn(true);
		movieMockMvc.perform(post("/api/v1/movie").header("authorization", "Bearer " + token).contentType(MediaType.APPLICATION_JSON).content(jsonToString(movie)))
		.andExpect(status().isCreated()).andDo(print());
		verify(service,times(1)).saveMovie(Mockito.any(Movie.class));
	}
	
	@Test
	public void testUpdateMovieSuccess() throws Exception
	{
		movie.setComments("not so good movie");		
		when(service.updateMovie(1,movie)).thenReturn(movies.get(0));
		movieMockMvc.perform(put("/api/v1/movie/{id}",1)
				.contentType(MediaType.APPLICATION_JSON)
				.content(jsonToString(movie)))
				.andExpect(status().isOk());
		//verify(service, times(1)).updateMovie(Mockito.any(Movie.class));
	}

	
	@Test
	public void testDeleteMovieById() throws Exception{
		// TODO Auto-generated method stub
		when(service.deleteMovieById(1)).thenReturn(true);
		movieMockMvc.perform(delete("/api/v1/movie/{id}",1)).andExpect(status().isOk());
		verify(service,times(1)).deleteMovieById(1);
		verifyNoMoreInteractions(service);
	}
	
	@Test
	public void testFetchMovieById() throws Exception{
		when(service.getMovieById(1)).thenReturn(movies.get(0));
		movieMockMvc.perform(get("/api/v1/movie/{id}",1)).andExpect(status().isOk());
		verify(service,times(1)).getMovieById(1);
		verifyNoMoreInteractions(service);
	}
	
	@Test
	public void testGetAllMovies() throws Exception{
		
		String token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhcnVuIiwiaWF0IjoxNTUzMzQzMjUwfQ.Fl0RnWL2nE9lWcbgzPkuxFIsdeaB-Eyrjjp6CLTU7q0";
		when(service.getMyMovies("arun")).thenReturn(movies);
		movieMockMvc.perform(get("/api/v1/movie").header("authorization", "Bearer " + token))
				.andExpect(status().isOk()).andDo(print());
		verify(service,times(1)).getMyMovies("arun");
		verifyNoMoreInteractions(service);
	}
	
	private static String jsonToString(final Object obj) throws JsonProcessingException {
		String result = null;
		try {
			final ObjectMapper mapper = new ObjectMapper();
			result = mapper.writeValueAsString(obj);
		} catch (Exception e) {
			result = "Json parse error";
		}
		return result;
	}


}
