package com.stackroute.moviecruiser.repositories;
//

//import javax.transaction.Transactional;
//import static org.assertj.core.api.Assertions.assertThat;
//import static org.junit.Assert.*;
//
//import java.util.List;
//import java.util.Optional;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
//import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
//import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import com.stackroute.moviecruiser.domain.Movie;
//import com.stackroute.moviecruiser.repository.MovieRepository;
//
//@RunWith(SpringRunner.class)
//@DataJpaTest
//@AutoConfigureTestDatabase(replace=Replace.NONE)
//@Transactional
//public class MovieRepoTest {
//
//	@Autowired
//	private transient MovieRepository repo;
//	
//	private void setRepo(final MovieRepository repo) {
//		// TODO Auto-generated method stub
//		this.repo=repo;
//	}
//	
//	
//	@Test
//	public void testSaveMovie() throws Exception{
//		repo.save(new Movie(1,"1234", "Superman", "good Movie", "www.abc.com", "2015-03-23",4.5,112,"John123"));
//		final Movie movie=repo.getOne(1);
//		assertThat(movie.getId()).isEqualTo(1);
//	}
//	
//	@Test
//	public void testUpdateMovie() throws Exception{
//		repo.save(new Movie(1,"1234", "Superman", "good Movie", "www.abc.com", "2015-03-23",4.5,112,"John123"));
//		final Movie movie=repo.getOne(1);
//		assertEquals(movie.getTitle(), "Superman");
//		movie.setComments("hi");
//		repo.save(movie);
//		final Movie tempMovie=repo.getOne(1);
//		assertEquals("hi", tempMovie.getComments());
//	}
//	
//	@Test
//	public void testDeleteMovie() throws Exception{
//		repo.save(new Movie(1,"1234", "Superman", "good Movie", "www.abc.com", "2015-03-23",4.5,112,"John123"));
//		final Movie movie=repo.getOne(1);
//		assertEquals(movie.getTitle(), "Superman");
//		repo.delete(movie);
//		assertEquals(Optional.empty(), repo.findById(1));
//	}
//	
//	@Test
//	public void testGetMovie() throws Exception{
//		// TODO Auto-generated method stub
//		repo.save(new Movie(1,"1234", "Superman", "good Movie", "www.abc.com", "2015-03-23",4.5,112,"John123"));
//		final Movie movie=repo.getOne(1);
//		assertEquals(movie.getTitle(),"Superman");
//	}
//	
//	@Test
//	public void testGetAllMovies() throws Exception{
//		repo.save(new Movie(1,"1234", "Superman", "good Movie", "www.abc.com", "2015-03-23",4.5,112,"John123"));
//		repo.save(new Movie(2,"1234", "Superman1", "good Movie", "www.abc.com", "2015-03-23",4.5,112,"John123"));
//		final List<Movie> movies=repo.findByUserId("John123");
//		assertEquals(movies.get(0).getTitle(),"Superman");
//	}
//
//}

import javax.transaction.Transactional;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;
import com.stackroute.moviecruiser.domain.Movie;
import com.stackroute.moviecruiser.repository.MovieRepository;
import static org.junit.Assert.*;

import java.util.List;
import java.util.Optional;
import static org.assertj.core.api.Assertions.*;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Transactional
public class MovieRepoTest {

	@Autowired
	private transient MovieRepository repo;
	
	public void setRepo(MovieRepository repo) {
		this.repo = repo;
	}

	@Test
	public void testSaveMovie() throws Exception {
		repo.save(new Movie(1, "123", "Bahubali", "blockbuster movie", "www.abc.com", "2014-07-08", 49.5, 100, "arun"));
		final Movie movie = repo.getOne(1);
		assertThat(movie.getId()).isEqualTo(1);
	}

	@Test
	public void testUpdateMovie() throws Exception {
		repo.save(new Movie(1, "123", "Bahubali", "blockbuster movie", "www.abc.com", "2014-07-08", 49.5, 100, "arun"));
		final Movie movie = repo.getOne(1);
		assertEquals(movie.getTitle(), "Bahubali");
		movie.setComments("hi");
		repo.save(movie);
		final Movie tempMovie = repo.getOne(1);
		assertEquals("hi", tempMovie.getComments());
	}

	@Test
	public void testDeleteMovie() throws Exception {
		repo.save(new Movie(1, "123", "Bahubali", "blockbuster movie", "www.abc.com", "2014-07-08", 49.5, 100, "arun"));
		final Movie movie = repo.getOne(1);
		assertEquals(movie.getTitle(), "Bahubali");
		repo.delete(movie);
		assertEquals(Optional.empty(), repo.findById(1));
	}

	@Test
	public void testGetMovie() throws Exception {
		repo.save(new Movie(1, "123", "Bahubali", "blockbuster movie", "www.abc.com", "2014-07-08", 49.5, 100, "arun"));
		final Movie movie = repo.getOne(1);
		assertEquals(movie.getTitle(), "Bahubali");
	}

	@Test
	public void testGetAllMovies() throws Exception {
		repo.save(new Movie(1, "123", "Bahubali", "blockbuster movie", "www.abc.com", "2014-07-08", 49.5, 100, "arun"));
		repo.save(new Movie(2, "123", "Bahubali-2", "blockbuster movie", "www.abc.com", "2014-07-08", 49.5, 100, "arun"));
		repo.save(new Movie(3, "123", "Spiderman", "blockbuster movie", "www.abc.com", "2014-07-08", 49.5, 100, "arun"));
		repo.save(new Movie(4, "123", "Superman", "blockbuster movie", "www.abc.com", "2014-07-08", 49.5, 100, "arun"));
		final List<Movie> movies = repo.findAll();
		assertEquals(movies.get(0).getTitle(), "Bahubali");
	}

}
