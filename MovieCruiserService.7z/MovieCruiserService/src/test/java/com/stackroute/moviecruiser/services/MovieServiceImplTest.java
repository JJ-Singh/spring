package com.stackroute.moviecruiser.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import static org.mockito.Mockito.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.stackroute.moviecruiser.domain.Movie;
import com.stackroute.moviecruiser.exception.MovieAlreadyExistsExceptions;
import com.stackroute.moviecruiser.exception.MovieNotFoundException;
import com.stackroute.moviecruiser.repository.MovieRepository;
import com.stackroute.moviecruiser.service.MovieServiceImpl;

public class MovieServiceImplTest {

	@Mock
	private transient MovieRepository movieRepo;
	
	private transient Movie movie;
	
	@InjectMocks
	private transient MovieServiceImpl movieServiceImpl;
	

	transient Optional<Movie> options;

	transient List<Movie> emptyMovies;

	@Before
	public void setupMock(){
		MockitoAnnotations.initMocks(this);
		movie= new Movie(1,"1234", "Superman", "good Movie", "www.abc.com", "2015-03-23",4.5,112,"John123");
		options=Optional.of(movie);
	}
	
	@Test
	public void testMockCreation(){
		assertNotNull(movie);
		assertNotNull("jpaRepository creation fails:use @injectMocks on movieService",movieRepo);
	}

	@Test
	public void testSaveMovieSuccess() throws MovieAlreadyExistsExceptions{
		when(movieRepo.save(movie)).thenReturn(movie);
		final boolean flag=movieServiceImpl.saveMovie(movie);
		assertEquals("saving movie failed ,the call to movieDAOImpl is returning false,check this method",true,flag);
		verify(movieRepo,times(1)).save(movie);
		verify(movieRepo,times(1)).findByMovieIdAndUserId(movie.getMovieId(),movie.getUserId());
	}
	
	@Test(expected=MovieAlreadyExistsExceptions.class)
	public void testSaveMovieFailure() throws MovieAlreadyExistsExceptions{
		when(movieRepo.findByMovieIdAndUserId(movie.getMovieId(),movie.getUserId())).thenReturn(options);
		when(movieRepo.save(movie)).thenReturn(movie);
		final boolean flag=movieServiceImpl.saveMovie(movie);
		assertFalse("saving movie failed", flag);
		verify(movieRepo,times(1)).findByMovieIdAndUserId(movie.getMovieId(),movie.getUserId());
	}
	
	@Test
	public void testUpdateMovie() throws MovieNotFoundException{
		when(movieRepo.findById(1)).thenReturn(options);
		when(movieRepo.save(movie)).thenReturn(movie);
		movie.setComments("not so good movie");
		final Movie movie1=movieServiceImpl.updateMovie(1,movie);
		assertEquals("updating movie failed","not so good movie", movie.getComments());
		verify(movieRepo,times(1)).save(movie);
		verify(movieRepo,times(1)).findById(movie.getId());
	}
	
	@Test
	public void testDeleteMovieById() throws MovieNotFoundException{
		when(movieRepo.findById(1)).thenReturn(options);
		doNothing().when(movieRepo).delete(movie);
		final boolean flag =movieServiceImpl.deleteMovieById(1);
		assertTrue("deleting movie failed", flag);
		verify(movieRepo,times(1)).delete(movie);
		verify(movieRepo,times(1)).findById(movie.getId());
	}
	
	@Test
	public void testGetMovieById() throws MovieNotFoundException{
		when(movieRepo.findById(1)).thenReturn(options);
		final Movie movie1=movieServiceImpl.getMovieById(1);
		assertEquals("fetching movie by id failed", movie1,movie);
		verify(movieRepo,times(1)).findById(movie.getId());
	}
	
	@Test
	public void testGetAllMovies(){
		final List<Movie> movieList=new ArrayList<>(1);
		when(movieRepo.findAll()).thenReturn(movieList);
		final List<Movie> movie1=movieServiceImpl.getMyMovies("John123");
		verify(movieRepo,times(1)).findByUserId("John123");
	}
}
