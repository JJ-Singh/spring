package com.stackroute.moviecruiser.service;

import java.util.List;

import com.stackroute.moviecruiser.domain.Movie;
import com.stackroute.moviecruiser.exception.MovieAlreadyExistsExceptions;
import com.stackroute.moviecruiser.exception.MovieNotFoundException;

public interface MovieService {
	/* method declaration for saving a movie
	 * @param movie
	 * @return true/false
	 * @throws MovieAlreadyExistsExceptions
	 */
	boolean saveMovie(Movie movie)throws MovieAlreadyExistsExceptions;
	
	/* method declaration for update a movie
	 * @param movie
	 * @return updated movie
	 * @throws MovieNotFoundException
	 */
	Movie updateMovie(int id,Movie movie)throws MovieNotFoundException;
	
	/* method declaration for deleting a movie by id
	 * @param movieid
	 * @return true/false
	 * @throws MovieNotFoundException
	 */
	boolean deleteMovieById(int id)throws MovieNotFoundException;
	
	/* method declaration for getting a movie by id
	 * @param movieid
	 * @return true/false
	 * @throws MovieNotFoundException
	 */
	Movie getMovieById(int id)throws MovieNotFoundException;
	
	/* method declaration for getting a list of movie
	 * @return list of movies
	 */
	List<Movie> getMyMovies(String userId);
}
