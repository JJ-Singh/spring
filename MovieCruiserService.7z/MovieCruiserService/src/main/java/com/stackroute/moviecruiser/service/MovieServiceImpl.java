/**
 * 
 */
package com.stackroute.moviecruiser.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.moviecruiser.domain.Movie;
import com.stackroute.moviecruiser.exception.MovieAlreadyExistsExceptions;
import com.stackroute.moviecruiser.exception.MovieNotFoundException;
import com.stackroute.moviecruiser.repository.MovieRepository;

/**
 * @author 736943
 *
 */
@Service
public class MovieServiceImpl implements MovieService {
	
	private final transient MovieRepository movieRepo;
	
	@Autowired
	 public MovieServiceImpl(final MovieRepository movieRepo) {
		// TODO Auto-generated constructor stub
		 super();
		 this.movieRepo=movieRepo;
	}
	
	/* 
	 * @see com.stackroute.moviecruiser.service.MovieService#saveMovie(com.stackroute.moviecruiser.domain.Movie)
	 */
	@Override
	public boolean saveMovie(Movie movie) throws MovieAlreadyExistsExceptions {
		// TODO Auto-generated method stub
		final Optional<Movie> object=movieRepo.findByMovieIdAndUserId(movie.getMovieId(),movie.getUserId());
		if(object.isPresent()) {
			throw new MovieAlreadyExistsExceptions("Couldnot save movie.Movie already exists");	
		}
		movieRepo.save(movie);
		return true;
	}

	/* 
	 * @see com.stackroute.moviecruiser.service.MovieService#updateMovie(com.stackroute.moviecruiser.domain.Movie)
	 */
	@Override
	public Movie updateMovie(int id,Movie updateMovie) throws MovieNotFoundException {
		// TODO Auto-generated method stub
		final Optional<Movie> object=movieRepo.findById(id);
		if(object.isPresent()) {
			Movie movie = object.get();
			movie.setComments(updateMovie.getComments());
			return movieRepo.save(movie);
		}
		throw new MovieNotFoundException("Couldnot find movie. Movie doesnot exists.");
	}

	/* 
	 * @see com.stackroute.moviecruiser.service.MovieService#deleteMovieById(int)
	 */
	@Override
	public boolean deleteMovieById(final int id) throws MovieNotFoundException {
		// TODO Auto-generated method stub
		final Movie movie=movieRepo.findById(id).orElse(null);
		if(movie== null) {
			throw new MovieNotFoundException("Couldnot find movie. Movie doesnot exists.");
		}
		movieRepo.delete(movie);
		return true;
	}

	/* 
	 * @see com.stackroute.moviecruiser.service.MovieService#getMovieById(int)
	 */
	@Override
	public Movie getMovieById(int id) throws MovieNotFoundException {
		// TODO Auto-generated method stub
		final Movie movie=movieRepo.findById(id).orElse(null);
		if(movie== null) {
			throw new MovieNotFoundException("Couldnot find movie. Movie doesnot exists.");
		}
		movieRepo.delete(movie);
		return movie;
	}

	/* 
	 * @see com.stackroute.moviecruiser.service.MovieService#getAllMovies()
	 */
	@Override
	public List<Movie> getMyMovies(String userId) {
		// TODO Auto-generated method stub
		return movieRepo.findByUserId(userId);
	}

}
