package com.stackroute.moviecruiser.exception;

/**
 * @author 736943
 *
 */
@SuppressWarnings("serial")
public class MovieAlreadyExistsExceptions extends Exception {

	String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	/* 
	 * @see java.lang.Throwable#toString()
	 */
	@Override
	public String toString() {
		return "MovieAlreadyExistsExceptions [message=" + message + "]";
	}

	/**
	 * @param message
	 */
	public MovieAlreadyExistsExceptions(String message) {
		super(message);
		this.message = message;
	}
	
}
