package com.stackroute.moviecruiser.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="movie")
public class Movie {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	
	private String movieId;

	private String title;

	private String comments;

	private String posterPath;
	
	private String releaseDate;

	private Double voteAverage;
	
	private int voteCount;
	
	private String userId;


	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getMovieId() {
		return movieId;
	}


	public void setMovieId(String movieId) {
		this.movieId = movieId;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getComments() {
		return comments;
	}


	public void setComments(String comments) {
		this.comments = comments;
	}


	public String getPosterPath() {
		return posterPath;
	}


	public void setPosterPath(String posterPath) {
		this.posterPath = posterPath;
	}


	public String getReleaseDate() {
		return releaseDate;
	}


	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}


	public Double getVoteAverage() {
		return voteAverage;
	}


	public void setVoteAverage(Double voteAverage) {
		this.voteAverage = voteAverage;
	}


	public int getVoteCount() {
		return voteCount;
	}


	public void setVoteCount(int voteCount) {
		this.voteCount = voteCount;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public Movie(int id, String movieId, String title, String comments, String posterPath, String releaseDate,
			Double voteAverage, int voteCount, String userId) {
		super();
		this.id = id;
		this.movieId = movieId;
		this.title = title;
		this.comments = comments;
		this.posterPath = posterPath;
		this.releaseDate = releaseDate;
		this.voteAverage = voteAverage;
		this.voteCount = voteCount;
		this.userId = userId;
	}


	@Override
	public String toString() {
		return "Movie [id=" + id + ", movieId=" + movieId + ", title=" + title + ", comments=" + comments
				+ ", posterPath=" + posterPath + ", releaseDate=" + releaseDate + ", voteAverage=" + voteAverage
				+ ", voteCount=" + voteCount + ", userId=" + userId + "]";
	}


	public Movie(String movieId, String title, String comments, String posterPath, String releaseDate,
			Double voteAverage, int voteCount, String userId) {
		super();
		this.movieId = movieId;
		this.title = title;
		this.comments = comments;
		this.posterPath = posterPath;
		this.releaseDate = releaseDate;
		this.voteAverage = voteAverage;
		this.voteCount = voteCount;
		this.userId = userId;
	}
	
}
