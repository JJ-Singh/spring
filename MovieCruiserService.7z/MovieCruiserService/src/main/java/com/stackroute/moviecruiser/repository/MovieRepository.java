package com.stackroute.moviecruiser.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.stackroute.moviecruiser.domain.Movie;

@Repository
public interface MovieRepository extends JpaRepository<Movie, Integer> {
	List<Movie> findByUserId(String userId);
	
//	@Query( value = "SELECT * FROM movie WHERE movie_id=?1",nativeQuery = true)
	Optional<Movie> findByMovieIdAndUserId(String movieId,String userId);
}
