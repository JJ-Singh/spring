import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProblemStatement } from '../model/ProblemStatement';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProblemStatementService {
  private url:string = "/assets/data.json";
  constructor(private http: HttpClient) { }
  getProblemStatementData(): Observable<ProblemStatement[]> {
    return this.http.get<ProblemStatement[]>(this.url);
  }
}
