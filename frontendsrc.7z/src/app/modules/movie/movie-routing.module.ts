import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContainerComponent } from './components/container/container.component';

const routes: Routes = [
    {
        path: "movies",
        children: [
            {path: "", redirectTo: "popular", pathMatch: "full"},
            {
                path: "popular",
                component: ContainerComponent,
                data: {
                    movieType: "popular"
                }
            },
            {
                path: "top_rated",
                component: ContainerComponent,
                data: {
                    movieType: "top_rated"
                }
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})
export class MovieRoutingModule{}