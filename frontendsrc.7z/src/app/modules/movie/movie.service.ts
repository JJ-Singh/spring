import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, from } from 'rxjs';
import { retry, map } from 'rxjs/operators';
import { Movie } from './movie';

@Injectable({
  providedIn: 'root'
})
export class MovieService {
  tmdbEndpoint: string = "https://api.themoviedb.org/3/movie/";
  imagePrefix: string = "https://image.tmdb.org/t/p/w500";
  apiKey: string = "e5dc618a85d798a96af2b5f9c3fe963a";
  constructor(private http: HttpClient) { 
  }

  getMovies(type: string, page: number = 1): Observable<Array<Movie>>{
    return this.http.get(this.tmdbEndpoint + type + "?api_key=" + this.apiKey + "&language=en-US&page=" + page).pipe(retry(3),
    map(this.pickMovieResults),
    map(this.transformPosterPath.bind(this)));
  }
  // getPopularMovies(page: number = 1): Observable<Array<Movie>> {
  //   return this.http.get(this.tmdbEndpoint + "popular?api_key=" + this.apiKey + "&language=en-US&page=" + page).pipe(retry(3),
  //   map(this.pickMovieResults),
  //   map(this.transformPosterPath.bind(this)));
  // }

  // getTopRatedMovies(page: number = 1): Observable<Array<Movie>> {
  //   return this.http.get(this.tmdbEndpoint + "top_rated?api_key=" + this.apiKey + "&language=en-US&page=" + page).pipe(retry(3),
  //   map(this.pickMovieResults),
  //   map(this.transformPosterPath.bind(this)));
  // }

  transformPosterPath(movies): Array<Movie>{
    return movies.map(movie => {
      movie.poster_path = `${this.imagePrefix}${movie.poster_path}`;
      return movie;
    });
  }
  pickMovieResults(response){
    return response['results'];
  }
}
