import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { MovieRoutingModule } from './movie-routing.module';
import { ThumbnailComponent } from './components/thumbnail/thumbnail.component';
import { ContainerComponent } from './components/container/container.component';
import { MaterialSharedModule } from '../material-shared/material-shared.module';

@NgModule({
  declarations: [ThumbnailComponent, ContainerComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    MovieRoutingModule,
    MaterialSharedModule
  ],
  exports: []
})
export class MovieModule { }
