package com.mobileco.exceptions;

public class MobilecoException extends Exception {

	public MobilecoException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
