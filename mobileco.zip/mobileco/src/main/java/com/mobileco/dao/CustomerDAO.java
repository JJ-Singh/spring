package com.mobileco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mobileco.exceptions.MobilecoException;
import com.mobileco.model.Address;
import com.mobileco.model.Customer;

public class CustomerDAO {

	public CustomerDAO() {
	}
	public int registerCustomer(Connection connObj,Customer customer) throws MobilecoException{
		PreparedStatement pstmt = null;
		ResultSet result = null;
		int key = 0;
		try {
			
			pstmt = connObj.prepareStatement("insert into customer(name,email,phone,password,address_id) values(?,?,?,?,?)");

				pstmt.setString(1, customer.getName());
				pstmt.setString(2, customer.getEmail());
				pstmt.setString(3, customer.getPhone());
				pstmt.setString(4, customer.getPassword());
				pstmt.setInt(5, customer.getAddress().getId());
				pstmt.executeUpdate();
				result = pstmt.getGeneratedKeys();
				if(result.next()){
					key = result.getInt("id");
				}
			
		} catch (SQLException e) {
			throw new MobilecoException("Exception in registerCustomer "+ e);
		} finally{
			try {
				if (pstmt!=null)
					pstmt.close();
				if (result!=null)
					result.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return key;
	}
	
	public void updateCustomer(Connection connObj, Customer customer) throws MobilecoException{
		PreparedStatement pstmt = null;
		try {
			pstmt = connObj.prepareStatement("update customer set name = ?, email = ?,phone = ?,password = ?,address_id = ? where id = ?");
			pstmt.setString(1, customer.getName());
			pstmt.setString(2,customer.getEmail());
			pstmt.setString(3,customer.getPhone());
			pstmt.setString(4,customer.getPassword());
			pstmt.setInt(5, customer.getAddress().getId());
			pstmt.setInt(6,customer.getId());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new MobilecoException("Exception in registerCustomer "+ e);
		} finally{
			try {
				if (pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Customer getCustomerById(Connection connObj,int id) throws MobilecoException{
		PreparedStatement pstmt = null;
		String name;
		String email;
		String phone;
		String password;
		Address address;
		ResultSet result = null;
		try {
			pstmt = connObj.prepareStatement("select * from customer as cus join address as ad on cus.address_id = ad.id where cus.id = "+id);
			result = pstmt.executeQuery();
			if(result.next()){
				name = result.getString("name");
				email = result.getString("email");
				phone = result.getString("phone");
				password = result.getString("password");
				address = new Address(result.getInt("address_id"),result.getInt("pincode"),result.getString("street"),result.getString("city"),result.getString("state"),result.getString("country"));
			} else{
				throw new MobilecoException("No customer found!");
			}
			
		} catch (SQLException e) {
			throw new MobilecoException("Exception in registerCustomer "+ e);
		} finally{
			try {
				if (pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return new Customer(id, name, email, phone, password, address);
	}
}
