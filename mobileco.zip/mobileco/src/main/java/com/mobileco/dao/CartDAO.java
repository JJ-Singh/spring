package com.mobileco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.mobileco.exceptions.MobilecoException;
import com.mobileco.model.Cart;
import com.mobileco.model.Customer;
import com.mobileco.model.Product;

public class CartDAO {

	public CartDAO() {
		// TODO Auto-generated constructor stub
	}
	public void addToCart(Connection connObj, Customer customer,Product product) throws MobilecoException{
		PreparedStatement pstmt = null;
		try {
			pstmt = connObj.prepareStatement("insert into cart(customer_id,product_id) values(?,?)");
			pstmt.setInt(1,customer.getId());
			pstmt.setInt(2,product.getId());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new MobilecoException("Exception in registerCustomer "+ e);
		} finally{
			try {
				if (pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	public void removeFromCart(Connection connObj, Customer customer,Product product) throws MobilecoException{
		PreparedStatement pstmt = null;
		try {
			pstmt = connObj.prepareStatement("delete from cart where customer_id = ? and product_id = ?");
			pstmt.setInt(1, customer.getId());
			pstmt.setInt(2, product.getId());
		} catch (SQLException e) {
			throw new MobilecoException("Exception in registerCustomer "+ e);
		} finally{
			try {
				if (pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public ArrayList<Cart> getItemsFromCart(Connection connection) throws MobilecoException{
		ArrayList<Cart> cartList = new ArrayList<Cart>();
		PreparedStatement pstmt = null;
		ResultSet result = null;
		try {
//			will add join operation;
//			pstmt = connection.prepareStatement("select * from cart");
//			result = pstmt.executeQuery();
//			int customerId;
//			int productId;
//			while(result.next()) {
//				customerId = result.getInt("customer_id");
//				productId = result.getInt("product_id");
//				cartList.add(new Cart(customer, product));
			}
			
		} catch (SQLException e) {
			throw new MobilecoException("Exception in registerCustomer "+ e);
		}
	}
}
