package com.mobileco.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mobileco.exceptions.MobilecoException;
import com.mobileco.model.Address;

public class AddressDAO {

	public AddressDAO() {
	}
	public int registerAddress(Connection connObj,Address address) throws MobilecoException{
		PreparedStatement pstmt = null;
		ResultSet result = null;
		int key = 0;
		try {
			pstmt = connObj.prepareStatement("insert into address(street,city,state,country,pincode) values(?,?,?,?,?)");
			pstmt.setString(1,address.getStreet());
			pstmt.setString(2,address.getCity());
			pstmt.setString(3, address.getState());
			pstmt.setString(4,address.getCountry());
			pstmt.setInt(5,address.getPincode());
			pstmt.executeUpdate();
			result = pstmt.getGeneratedKeys();
			if(result.next()){
				key = result.getInt("id");
			}
		} catch (SQLException e) {
			throw new MobilecoException("Exception in registerCustomer "+ e);
		} finally{
			try {
				if (pstmt!=null)
					pstmt.close();
				if (result!=null)
					result.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return key;
	}
	
	public void updateAddress(Connection connObj,Address address) throws MobilecoException{
		PreparedStatement pstmt = null;
		try {
			pstmt = connObj.prepareStatement("update address set street = ?, city = ?,state = ?,country = ?,pincode = ? where id = ?");
			pstmt.setString(1,address.getStreet());
			pstmt.setString(2, address.getCity());
			pstmt.setString(3, address.getState());
			pstmt.setString(4, address.getCountry());
			pstmt.setInt(5, address.getPincode());
			pstmt.setInt(6, address.getId());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new MobilecoException("Exception in registerCustomer "+ e);
		} finally{
			try {
				if (pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Address getAddressById(Connection connObj,int id) throws MobilecoException{
		PreparedStatement pstmt = null;
		ResultSet result = null;
		String street;
		String city;
		String state;
		String country;
		int pincode;
		try {
			pstmt =  connObj.prepareStatement("select * from address where id = "+ id);
			result = pstmt.executeQuery();
			if(result.next()){
				street =  result.getString("street");
				city = result.getString("city");
				state = result.getString("state");
				country = result.getString("country");
				pincode = result.getInt("pincode");
			} else{
				throw new MobilecoException("No address found!");
			}
		} catch (SQLException e) {
			throw new MobilecoException("Exception in registerCustomer "+ e);
		} finally{
			try {
				if (pstmt!=null)
					pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return new Address(id, pincode, street, city, state, country);
	}
}
