package com.mobileco.model;

public class Product {

	public Product() {
		// TODO Auto-generated constructor stub
	}

	private int id;
	private Accessories accessories;
	private Mobile mobile;
	public Product(int id, Accessories accessories, Mobile mobile) {
		super();
		this.id = id;
		this.accessories = accessories;
		this.mobile = mobile;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Accessories getAccessories() {
		return accessories;
	}
	public void setAccessories(Accessories accessories) {
		this.accessories = accessories;
	}
	public Mobile getMobile() {
		return mobile;
	}
	public void setMobile(Mobile mobile) {
		this.mobile = mobile;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accessories == null) ? 0 : accessories.hashCode());
		result = prime * result + id;
		result = prime * result + ((mobile == null) ? 0 : mobile.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (accessories == null) {
			if (other.accessories != null)
				return false;
		} else if (!accessories.equals(other.accessories))
			return false;
		if (id != other.id)
			return false;
		if (mobile == null) {
			if (other.mobile != null)
				return false;
		} else if (!mobile.equals(other.mobile))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Product [id=" + id + ", accessories=" + accessories + ", mobile=" + mobile + "]";
	}
	
	
}
